import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('schoolComputerScreen')
export class schoolComputerScreen extends Component {
    start() {

    }

    update(deltaTime: number) {
        
    }
    open(){
        
    }
}


