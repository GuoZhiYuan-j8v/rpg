import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('foodWindows')
export class foodWindows extends Component {
    start() {

    }

    update(deltaTime: number) {
        
    }
}


