"use strict";

const resolution = require("../lib/index.cjs");

console.log(resolution.list());